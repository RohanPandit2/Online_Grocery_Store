# Online-Grocery-Shopping
This mini project was to build the online grocery shopping using php , mysql and javascripct. Which have all the ecommerce features like create , update, read and Delete and the user authentication.
Online Shopping Portal
-------------------------------------------
Project Name -----------	Online Shopping Portal
Language Used -----------  	PHP5.6, PHP7.x
Database 	-------------------MySQL 5.x
User Interface Design  ------- 	HTML, AJAX,JQUERY,JAVASCRIPT
Web Browser -----------	Mozilla, Google Chrome, IE8, OPERA
Software -----------	XAMPP / Wamp / Mamp/ Lamp (anyone)
Last Updated 	27 july 2020
--------------------------------------------------------------------------------------------------------------

E-commerce means any transaction over the internet.
In online marketing, a shopping cart is a piece of e-commerce software on a web server that allows visitors
to an Internet site to select items for eventual purchase, analogous to the American English term “shopping cart.”
In British English, it is generally known as a shopping basket, almost exclusively shortened on websites to “basket.”
The software allows online shopping customers to accumulate a list of items for purchase,
described metaphorically as “placing items in the shopping cart” or “add to cart.” Upon checkout,
the software typically calculates a total for the order, including shipping and handling (i.e., postage and packing) 
charges and the associated taxes, as applicable.

-----------------------------------------------------------------------------------------------------------------
Features of the Project

    User Registration
    User login system
    Change password
    Forgot password
    Profile management system.
    Shopping cart
    Wishlist
    Order History
    
    ---------------------------------------------------------
    Features of Admin

    Product Management(Add,Update, Delete)
    Order Management System
    User Management
    Category/ Sub Category Creation and many more

How to run this Project

    Download the project and unzip the file, or you can clone it directly with the link.
    Create database “shopping”.
    Import the database file( Database will be avail in the package)
     Link for the project: http://localhost/shopping
    Link for admin Panel: http://localhost/shopping/admin
---------------------------------------------------------------------
    For Admin :
User Name: admin
Password: Test@123
you can change the admin password by yourself
-------------------------------------------------------------
